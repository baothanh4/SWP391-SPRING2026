package com.example.SWP391_SPRING2026;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Swp391Spring2026ApplicationTests {

	@Test
	void contextLoads() {
	}

}
