package com.example.SWP391_SPRING2026.DTO.Request;

import lombok.Data;

@Data
public class VariantAttributeRequestDTO {
    private String attributeName;
    private String attributeValue;
}
