package com.example.SWP391_SPRING2026.Enum;

public enum ShipmentStatus {
    WAITING_CONFIRM,   // COD: chờ staff confirm
    PREPARING,         // đang đóng gói
    SHIPPED,
    DELIVERED,
    CANCELLED,
    READY_TO_PICK,
    PICKING,
    DELIVERING,
    FAILED,
    RETURNED
}
