package com.example.SWP391_SPRING2026.Service;

import com.example.SWP391_SPRING2026.DTO.Request.ChangePasswordDTO;
import com.example.SWP391_SPRING2026.DTO.Request.CustomerAccountResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.AddressResponseDTO;
import com.example.SWP391_SPRING2026.DTO.Response.CustomerAccountUpdateDTO;
import com.example.SWP391_SPRING2026.DTO.Response.OrderResponseDTO;
import com.example.SWP391_SPRING2026.Entity.Address;
import com.example.SWP391_SPRING2026.Entity.Order;
import com.example.SWP391_SPRING2026.Entity.Users;
import com.example.SWP391_SPRING2026.Enum.*;
import com.example.SWP391_SPRING2026.Exception.BadRequestException;
import com.example.SWP391_SPRING2026.Exception.DuplicateResourceException;
import com.example.SWP391_SPRING2026.Repository.OrderRepository;
import com.example.SWP391_SPRING2026.Repository.UserRepository;
import jakarta.transaction.Transactional;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CustomerService {
    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final OrderRepository orderRepository;
    private final OrderCancellationService orderCancellationService;


    public CustomerAccountResponseDTO getProfile(Long userId){
        Users user =  userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));
        return map(user);
    }

    public CustomerAccountResponseDTO updateProfile(Long userId, CustomerAccountUpdateDTO dto){
        Users user =  userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        if(dto.getFullName() != null){
            user.setFullName(dto.getFullName());
        }

        if(dto.getPhone() != null && !dto.getPhone().equals(user.getPhone())){
            if(userRepository.existsByPhone(dto.getPhone())){
                throw new DuplicateResourceException("PHONE_EXISTS", "Phone already exists");
            }
            user.setPhone(dto.getPhone());
        }

        if(dto.getDob() != null){
            user.setDob(dto.getDob());
        }

        if(dto.getGender() != null){
            user.setGender(dto.getGender());
        }

        return map(userRepository.save(user));
    }

    public void changePassword(Long userId, ChangePasswordDTO dto){
        Users user =  userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        if(!passwordEncoder.matches(dto.getOldPassword(), user.getPassword())){
            throw new BadRequestException("Old Password is incorrect");
        }

        user.setPassword(passwordEncoder.encode(dto.getNewPassword()));
        userRepository.save(user);
    }

    public void disableAccount(Long userId){
        Users user =  userRepository.findById(userId).orElseThrow(() -> new RuntimeException("User not found"));

        user.setStatus(UserStatus.INACTIVE);
        userRepository.save(user);
    }

    @Transactional
    public void cancelOrderByCustomer(Long userId, Long orderId){
        orderCancellationService.cancelByCustomer(userId, orderId);
    }

    public List<OrderResponseDTO> getMyOrders(Long userId){
        List<Order> orders = orderRepository.findByUserIdOrderByCreatedAtDesc(userId);

        return orders.stream()
                .map(this::map)
                .toList();
    }

    public OrderResponseDTO getMyOrderById(Long userId, Long orderId){

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new BadRequestException("Order not found"));

        // Check order ownership
        if(!order.getUser().getId().equals(userId)){
            throw new BadRequestException("You are not allowed to view this order");
        }

        return map(order);
    }

    private CustomerAccountResponseDTO map(Users u) {
        return new CustomerAccountResponseDTO(
                u.getId(),
                u.getEmail(),
                u.getPhone(),
                u.getFullName(),
                u.getGender(),
                u.getDob(),
                u.getStatus(),
                u.getCreateAt()
        );
    }

    private OrderResponseDTO map(Order order){

        OrderResponseDTO dto = new OrderResponseDTO();

        dto.setId(order.getId());
        dto.setOrderCode(order.getOrderCode());
        dto.setOrderType(order.getOrderType());
        dto.setOrderStatus(order.getOrderStatus());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setDeposit(order.getDeposit());
        dto.setRemainingAmount(order.getRemainingAmount());

        if(order.getAddress() != null){
            AddressResponseDTO addressDTO = new AddressResponseDTO();

            addressDTO.setId(order.getAddress().getId());
            addressDTO.setReceiverName(order.getAddress().getReceiverName());
            addressDTO.setPhone(order.getAddress().getPhone());
            addressDTO.setAddressLine(order.getAddress().getAddressLine());

            dto.setAddress(addressDTO);
        }

        return dto;
    }

}
