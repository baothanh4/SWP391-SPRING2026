package com.example.SWP391_SPRING2026.DTO.Request;

import lombok.Data;

@Data
public class LoginRequest {
    private String username;
    private String password;
}
