package com.example.SWP391_SPRING2026.Enum;

public enum PaymentStatus {
    PENDING,
    SUCCESS,
    FAILED,
    UNPAID,
    CANCELLED,
    PAID
}
