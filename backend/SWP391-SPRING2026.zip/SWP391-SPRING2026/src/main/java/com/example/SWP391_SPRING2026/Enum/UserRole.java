package com.example.SWP391_SPRING2026.Enum;

public enum UserRole {
    CUSTOMER,
    SUPPORT_STAFF,
    OPERATION_STAFF,
    MANAGER,
    ADMIN
}
