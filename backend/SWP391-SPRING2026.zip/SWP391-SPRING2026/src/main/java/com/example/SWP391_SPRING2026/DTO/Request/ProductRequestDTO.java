package com.example.SWP391_SPRING2026.DTO.Request;

import lombok.Data;

@Data
public class ProductRequestDTO {
    private String name;
    private String description;
    private String brandName;
    private String productImage;
}
