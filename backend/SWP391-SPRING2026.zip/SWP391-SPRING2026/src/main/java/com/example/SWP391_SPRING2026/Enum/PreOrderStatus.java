package com.example.SWP391_SPRING2026.Enum;

public enum PreOrderStatus {
    WAITING,
    PREPARING,
    SHIPPED,
    DELIVERED
}
