package com.example.SWP391_SPRING2026.Enum;

public enum PaymentMethod {
    COD,
    VNPAY
}
